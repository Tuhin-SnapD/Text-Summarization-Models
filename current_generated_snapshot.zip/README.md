# Text Summarization Models - A Comprehensive Educational Repository

This repository contains educational implementations of text summarization models, ranging from basic statistical approaches to transformer-based architectures. It demonstrates both **extractive** (selecting key sentences) and **abstractive** (generating new content) approaches.

Text summarization creates a shorter version of a longer text while preserving important information. The notebooks cover statistical, graph-based, matrix, clustering, classical NLP, and neural methods.

## Evaluation Metrics

The notebooks report:

- **ROUGE (Recall-Oriented Understudy for Gisting Evaluation):** precision, recall, and F1 for overlap between a generated summary and a reference summary.
- **BLEU (Bilingual Evaluation Understudy):** n-gram overlap with a reference summary.

## Quick Start Guide

### Prerequisites

Python 3.10 or newer is recommended for the current notebooks. The classical notebook examples and common evaluation helpers use the Python standard library. Transformer inference additionally requires PyTorch, Transformers, and model weights.

```powershell
python --version
python -m pip install -r requirements-models.txt
```

### Basic Usage Example

The original example used the `bert-extractive-summarizer` package. The current BERT notebook keeps this as an optional example; the shared no-install baseline is:

```python
from summarization_utils import load_article, summarize

article = load_article()
summary = summarize(article, method="tfidf", sentence_count=3)
print(summary)
```

### Running a Specific Model

Open a notebook from either model folder in Jupyter. To execute the Python cells of every notebook and save the outputs, run:

```powershell
python run_all_notebooks.py
```

This lightweight runner records code-cell outputs but is not a Jupyter kernel. The notebook files remain usable interactively in Jupyter.

## Model Performance Comparison Table

The original README reported the following values. They are retained here as historical project values; they were not generated with the shared 2026 article/reference setup and should not be compared directly with the updated results below.

| Model | Type | ROUGE F1 | BLEU | Pros | Cons | Best For |
|---|---|---:|---:|---|---|---|
| GPT-2 | Abstractive | 0.797 | 0.423 | High recall, contextual | Low control, expensive | Research, complex documents |
| LSA | Extractive | 0.602 | 0.869 | Semantic relationships | Needs large data | Multi-document |
| TextRank | Extractive | 0.586 | 0.694 | Unbiased, consistent | Limited context | General purpose |
| T5 | Abstractive | 0.573 | 0.683 | High accuracy, multilingual | Resource intensive | Production systems |
| NLTK | Extractive | 0.589 | 0.869 | Simple implementation | Limited accuracy | Beginners |
| BERT | Extractive | 0.545 | 0.677 | Context understanding | Extractive only | Context-heavy documents |
| BART | Abstractive | 0.402 | 0.905 | High-quality generation | Large model size | High-quality summaries |
| LexRank | Extractive | 0.357 | 0.651 | Handles complex texts | Extractive only | Long documents |
| SumBasic | Extractive | 0.589 | 0.621 | Simple implementation | Limited coverage | Single documents |

## Model Categories

### 1. Basic Statistical Models

- **NLTK** (`NLTK.ipynb`): word-frequency sentence scoring; useful for learning basic extractive summarization.
- **TF-IDF** (`TFIDF_Sentence_Ranking_Comparison.ipynb`): sentence scoring from term frequency and inverse document frequency.
- **SumBasic** (`SumBasic.ipynb`): probabilistic sentence selection based on word frequency.

### 2. Graph-Based Models

- **TextRank** (`TextRank.ipynb`): sentence-similarity graph ranking.
- **LexRank** (`LexRank_Gensim_Comparison.ipynb`): lexical centrality on a sentence similarity graph.
- **Connected Dominating Set** (`Connected_Dominating_Set.ipynb`): graph coverage approximation for selecting representative sentences.
- **Graph-Based Summary** (`Graph_Based_Summary.ipynb`): graph-centrality example in the proposed architecture group in the original repository; it is now in the basic-to-advanced group to maintain the requested 18 + 12 notebook layout.

### 3. Matrix Decomposition Models

- **LSA (Latent Semantic Analysis)** (`LSA.ipynb`): sentence importance from a leading latent term-space component.
- **Sentence Ranking** (`TFIDF_Sentence_Ranking_Comparison.ipynb`): a TF-IDF sentence-scoring comparison.

### 4. Clustering-Based Models

- **K-Clustering** and **Cluster-Based Summarization** (`Clustering_Comparison.ipynb`): deterministic clustering-style sentence representatives.

### 5. Advanced NLP Models

- **Luhn's Model** (`Luhn's_Model.ipynb`): frequency and salient-term density sentence selection.
- **Compressive Document Summarization** (`Compressive_Document_Summarization.ipynb`): a length-constrained extractive approximation.
- **SUMY-style reduction** (`SUMY.ipynb`): centrality scoring with redundancy reduction.
- **Gensim-style TextRank** (`LexRank_Gensim_Comparison.ipynb`): dependency-free educational reimplementation.

### 6. Transformer-Based Models

- **BERT** (`BERT.ipynb`): optional BERT-based extractive summarizer.
- **BART** (`BART.ipynb`): optional abstractive sequence-to-sequence model.
- **T5** (`T5.ipynb`): optional text-to-text summarization model.
- **GPT-2** (`GPT_2.ipynb`): optional continuation model; it is not fine-tuned for instruction-following summarization.
- **DistilBART** (`Distilbart.ipynb`): optional distilled abstractive model.
- **Transformer Pipeline** (`AI_Transformer_pipeline.ipynb`): optional Hugging Face summarization pipeline.

These notebooks require the model dependencies and weights. If unavailable, their code reports a skip rather than pretending to produce an inference result.

## Advanced Architecture Models

### Pegasus Checkpoints

The proposed architecture folder contains **12 separate notebooks**, each tied to one Pegasus checkpoint:

| Notebook | Checkpoint / domain |
|---|---|
| `Pegasus_XSum.ipynb` | `google/pegasus-xsum` - extreme summarization |
| `Pegasus_CNN_DailyMail.ipynb` | `google/pegasus-cnn_dailymail` - news articles |
| `Pegasus_Newsroom.ipynb` | `google/pegasus-newsroom` - news articles |
| `Pegasus_MultiNews.ipynb` | `google/pegasus-multi_news` - multi-document news |
| `Pegasus_Gigaword.ipynb` | `google/pegasus-gigaword` - headline generation |
| `Pegasus_WikiHow.ipynb` | `google/pegasus-wikihow` - how-to articles |
| `Pegasus_Reddit_TIFU.ipynb` | `google/pegasus-reddit_tifu` - Reddit stories |
| `Pegasus_BigPatent.ipynb` | `google/pegasus-big_patent` - patents |
| `Pegasus_ArXiv.ipynb` | `google/pegasus-arxiv` - scientific papers |
| `Pegasus_PubMed.ipynb` | `google/pegasus-pubmed` - biomedical literature |
| `Pegasus_AESLC.ipynb` | `google/pegasus-aeslc` - email subject lines |
| `Pegasus_BillSum.ipynb` | `google/pegasus-billsum` - U.S. bills |

## Shared Article and Evaluation (Added October 30, 2026)

All 30 notebooks now use one shared article and one reference summary:

- [`article.txt`](article.txt) is a curated, paraphrased article based on NOAA NCEI's [global 2025 climate assessment](https://www.ncei.noaa.gov/news/global-climate-202513), published January 14, 2026.
- [`reference_summary.txt`](reference_summary.txt) is the common human-written target summary.
- [`summarization_utils.py`](summarization_utils.py) contains the shared classical implementations and consistent ROUGE-1/2/L F1 and smoothed BLEU-4 metrics.
- [`run_all_notebooks.py`](run_all_notebooks.py) runs all notebook Python cells and saves outputs.

The repository layout is **18 notebooks** in `Basic to Advance Text Summarisation Models/` plus **12 Pegasus notebooks** in `Models Used in Proposed Architecture/`, for **30 notebooks total**. Three overlapping pairs of examples are combined in comparison notebooks; the techniques remain represented.

## Results from the Shared Article

These are single-example results against `reference_summary.txt`, not a general benchmark or model ranking. All values are F1 except BLEU-4. A dash means pretrained inference was unavailable in the environment when run, not a zero score.

| Basic-to-advanced notebook | ROUGE-1 | ROUGE-2 | ROUGE-L | BLEU-4 | Status |
|---|---:|---:|---:|---:|---|
| AI Transformer pipeline | — | — | — | — | Optional model runtime unavailable |
| BART | — | — | — | — | Optional model runtime unavailable |
| BERT | — | — | — | — | Optional model runtime unavailable |
| Clustering comparison | 0.176 | 0.060 | 0.098 | 0.041 | Ran |
| Compressive Document Summarization | 0.268 | 0.043 | 0.169 | 0.049 | Ran |
| Connected Dominating Set | 0.403 | 0.115 | 0.210 | 0.091 | Ran |
| DistilBART | — | — | — | — | Optional model runtime unavailable |
| GPT-2 | — | — | — | — | Optional model runtime unavailable |
| Graph-Based Summary | 0.321 | 0.089 | 0.190 | 0.081 | Ran |
| LSA | 0.215 | 0.031 | 0.138 | 0.038 | Ran |
| Luhn | 0.321 | 0.089 | 0.190 | 0.081 | Ran |
| NLTK frequency | 0.244 | 0.033 | 0.130 | 0.037 | Ran |
| LexRank and Gensim-style TextRank | 0.321 | 0.089 | 0.190 | 0.081 | Ran |
| SumBasic | 0.333 | 0.089 | 0.158 | 0.068 | Ran |
| SUMY-style reduction | 0.321 | 0.089 | 0.190 | 0.081 | Ran |
| T5 | — | — | — | — | Optional model runtime unavailable |
| TextRank | 0.321 | 0.089 | 0.190 | 0.081 | Ran |
| TF-IDF and Sentence Ranking | 0.154 | 0.000 | 0.077 | 0.019 | Ran |

All 12 Pegasus notebooks use optional inference. Their actual model runs depend on installing the packages and downloading each checkpoint. Some classical examples are intentionally dependency-free approximations rather than wrappers around the original Gensim, SUMY, or scikit-learn libraries.

## Technical Requirements

### Core Examples

- Python 3.10+
- No third-party dependencies for the shared classical methods and evaluation helper

### Optional Pretrained Models

```powershell
python -m pip install -r requirements-models.txt
```

Disk and memory use depends on the chosen checkpoint. Pegasus checkpoints are large; load them one at a time. GPU is optional but recommended for practical transformer inference.

## Educational Value

This repository is intended to help readers:

1. Understand extractive and abstractive approaches.
2. Compare statistical, graph, matrix, clustering, and neural methods.
3. Examine runnable implementations and shared evaluation.
4. Learn practical differences in resource requirements and model assumptions.

### Learning Path Recommendations

- **Beginner:** NLTK frequency, TF-IDF, and SumBasic.
- **Intermediate:** graph methods, LSA, and clustering comparisons.
- **Advanced:** BERT, BART, T5, GPT-2, and Pegasus when model dependencies are available.

## Use Cases and Model Selection

- **Simple documents:** NLTK frequency, TF-IDF, or SumBasic.
- **Longer documents:** graph ranking or LSA-style scoring.
- **Multiple documents:** Pegasus MultiNews checkpoint.
- **Resource-constrained runs:** the dependency-free classical notebooks.
- **Research:** compare multiple approaches using a consistent reference summary, then use a proper dataset with multiple references for a meaningful benchmark.

## Research Areas Covered

- Extractive versus abstractive summarization
- Statistical versus neural approaches
- Graph-based, matrix-based, and clustering methods
- Traditional NLP versus transformer models
- Single-document and multi-document summarization

## Common Issues and Troubleshooting

- **Installation:** install optional packages from `requirements-models.txt` only when using transformer notebooks.
- **Model loading:** ensure network access and enough disk space for model checkpoints.
- **Memory:** run Pegasus checkpoints sequentially and close unused models.
- **Jupyter execution:** the included runner saves Python-cell outputs; interactive work requires a Jupyter installation and kernel.

## Contributing

Contributions are welcome, particularly additional model implementations, optimizations, documentation, evaluation metrics, and domain-specific adaptations. Keep examples reproducible and state clearly which dependencies and data they require.

## Acknowledgements

This repository began as an academic capstone project at Vellore Institute of Technology. The original project acknowledged Prof. Durgesh Kumar and the faculty members, Hugging Face, NLTK, and the academic research community.

## License

This project is presented for educational purposes. Check the licenses of individual model checkpoints, libraries, and referenced research before reuse, especially for commercial use.

## Support and Contact

Use GitHub issues for bug reports, discussions for questions, and pull requests for contributions.

---

**Version note:** The original README described 31 summarization models. The repository now has 30 notebooks arranged as 18 + 12; some notebooks contain more than one comparison method, and one Pegasus notebook corresponds to one checkpoint.
